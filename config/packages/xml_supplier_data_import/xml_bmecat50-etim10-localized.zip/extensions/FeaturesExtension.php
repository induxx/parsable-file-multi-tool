<?php

namespace Extensions;

use Misery\Component\Common\Options\OptionsTrait;
use Misery\Component\Common\Pipeline\Exception\SkipPipeLineException;
use Misery\Component\Configurator\ReadOnlyConfiguration;
use Misery\Component\Extension\ExtensionInterface;

class FeaturesExtension implements ExtensionInterface
{
    use OptionsTrait;

    private ReadOnlyConfiguration $configuration;
    private array $options = [
        'features' => [],
        'feature_locator' => 'PRODUCT_FEATURES|FEATURE|',
    ];

    public function __construct(ReadOnlyConfiguration $configuration, array $options)
    {
        $this->configuration = $configuration;
        $this->setOptions($options);
    }

    public function apply($item): array
    {
        $groupId = $this->resolveGroupId($item) ?? null;
        if (!$groupId) {
            throw new SkipPipeLineException('no GROUP_ID found');
        }

        $this->cleanupGroupIdFields($item);
        $featureLocator = $this->getOption('feature_locator');

        foreach ($item as $key => $value) {
            if (str_starts_with($key, $featureLocator)) {
                $featureKey = str_replace($featureLocator, '', $key);
                $featureKey = $groupId . '_' . $featureKey;
                $item[$featureKey] = $value;
                unset($item[$key]);

                if (str_ends_with($featureKey, '|0')) {
                    unset($item[$featureKey]);
                    $featureKey = str_replace('|0', '', $featureKey). '_min';
                    $item[$featureKey] = $value;
                    continue;
                }
                if (str_ends_with($featureKey, '|1')) {
                    unset($item[$featureKey]);
                    $featureKey = str_replace('|1', '', $featureKey). '_max';
                    $item[$featureKey] = $value;
                    continue;
                }

                if (str_starts_with($value, 'EV')) { # $attribute['type'] === 'pim_catalog_simpleselect'
                    $item[$featureKey] = $featureKey . '_' . $value;
                }
            }
        }
        $item['family'] = $groupId;

        return $item;
    }

    private function resolveGroupId(array $item): ?string
    {
        $groupId = $item['PRODUCT_FEATURES|REFERENCE_FEATURE_GROUP_ID'] ?? null;
        if (is_string($groupId) && str_starts_with($groupId, 'EC')) {
            return $groupId;
        }

        foreach ($item as $key => $value) {
            if (str_starts_with($key, 'PRODUCT_FEATURES|REFERENCE_FEATURE_GROUP_ID|') === false) {
                continue;
            }

            if (is_string($value) && str_starts_with($value, 'EC')) {
                return $value;
            }
        }

        return null;
    }

    private function cleanupGroupIdFields(array &$item): void
    {
        unset($item['PRODUCT_FEATURES|REFERENCE_FEATURE_GROUP_ID']);

        foreach (array_keys($item) as $key) {
            if (str_starts_with($key, 'PRODUCT_FEATURES|REFERENCE_FEATURE_GROUP_ID|')) {
                unset($item[$key]);
            }
        }
    }
}
