<?php

namespace Extensions;

use Misery\Component\Common\Options\OptionsTrait;
use Misery\Component\Configurator\ReadOnlyConfiguration;
use Misery\Component\Extension\ExtensionInterface;

class FeaturesExtension implements ExtensionInterface
{
    use OptionsTrait;

    private ReadOnlyConfiguration $configuration;
    private array $options = [
        'features' => [],
        'feature_locator' => 'PRODUCT_FEATURES|FEATURE|',
    ];

    public function __construct(ReadOnlyConfiguration $configuration, array $options)
    {
        $this->configuration = $configuration;
        $this->setOptions($options);
    }

    public function apply($item): array
    {
        $groupId = $item['PRODUCT_FEATURES|REFERENCE_FEATURE_GROUP_ID'] ?? null;
        $featureLocator = $this->getOption('feature_locator');

        foreach ($item as $key => $value) {
            if (str_starts_with($key, $featureLocator)) {
                $featureKey = str_replace($featureLocator, '', $key);
                $featureKey = $groupId . '_' . $featureKey;
                $item[$featureKey] = $value;
                unset($item[$key]);
            }
        }

        return $item;
    }
}