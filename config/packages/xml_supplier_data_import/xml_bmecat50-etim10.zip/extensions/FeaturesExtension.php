<?php

namespace Extensions;

use Misery\Component\Common\Options\OptionsTrait;
use Misery\Component\Configurator\ReadOnlyConfiguration;
use Misery\Component\Extension\ExtensionInterface;
use Misery\Component\Reader\ItemReaderInterface;

class FeaturesExtension implements ExtensionInterface
{
    use OptionsTrait;

    private ItemReaderInterface|null $attrReader = null;

    private ReadOnlyConfiguration $configuration;
    private array $options = [
        'features' => [],
        'feature_locator' => 'PRODUCT_FEATURES|FEATURE|',
    ];

    public function __construct(ReadOnlyConfiguration $configuration, array $options)
    {
        $this->configuration = $configuration;
        $this->setOptions($options);
    }

    public function apply($item): array
    {
        if (null === $this->attrReader) {
            $this->attrReader = $this->configuration->getSources()->get($this->getOption('attribute_source'))->getCachedReader();
        }

        $groupId = $item['PRODUCT_FEATURES|REFERENCE_FEATURE_GROUP_ID'] ?? null;
        unset($item['PRODUCT_FEATURES|REFERENCE_FEATURE_GROUP_ID']);
        $featureLocator = $this->getOption('feature_locator');

        foreach ($item as $key => $value) {
            if (str_starts_with($key, $featureLocator)) {
                $featureKey = str_replace($featureLocator, '', $key);
                $featureKey = $groupId . '_' . $featureKey;
                $item[$featureKey] = $value;
                unset($item[$key]);

                if (str_ends_with($featureKey, '|0')) {
                    unset($item[$featureKey]);
                    $featureKey = str_replace('|0', '', $featureKey). '_min';
                    $item[$featureKey] = $value;
                    continue;
                }
                if (str_ends_with($featureKey, '|1')) {
                    unset($item[$featureKey]);
                    $featureKey = str_replace('|1', '', $featureKey). '_max';
                    $item[$featureKey] = $value;
                    continue;
                }

                //$attribute = $this->attrReader->find(['code' => $featureKey])->getIterator()->current();
                if (str_starts_with($value, 'EV')) { # $attribute['type'] === 'pim_catalog_simpleselect'
                    $item[$featureKey] = $featureKey . '_' . $value;
                }
            }
        }
        $item['family'] = $groupId;

        return $item;
    }
}