<?php

namespace Extensions;

use Misery\Component\Common\Options\OptionsTrait;
use Misery\Component\Configurator\ReadOnlyConfiguration;
use Misery\Component\Extension\ExtensionInterface;

class FindSkuExtension implements ExtensionInterface
{
    use OptionsTrait;

    private ReadOnlyConfiguration $configuration;
    private array $options = [
        'list' => null,
        'identifier_field' => null,
    ];

    public function __construct(ReadOnlyConfiguration $configuration, array $options)
    {
        $this->configuration = $configuration;
        $this->setOptions($options);
    }

    public function apply($item): array
    {
        $list = $this->getOption('list', null);
        $identifier = $this->getOption('identifier_field');
        if (null === $list || $identifier === null) {
            return $item;
        }

        $id = $item['sku_txt-gsv'];
        if (isset($list[$id])) {
            $identifier = $list[$id];
            $item[$identifier] = $identifier;
        }
        return $item;
    }
}